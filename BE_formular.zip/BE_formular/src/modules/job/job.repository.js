import * as db from '../../helpers/db.js';

class JobRepository {
    async findAll({ search, location, type, tags }) {
        let sql = `SELECT j.*, c.name as "companyName", c.logo as "companyLogo" FROM jobs j 
                   LEFT JOIN companies c ON j.companyId = c.id WHERE j.isActive = true`;
        let params = [];
        if (search) { params.push(`%${search}%`); sql += ` AND (j.title ILIKE $${params.length} OR j.description ILIKE $${params.length})`; }
        if (location) { params.push(location); sql += ` AND j.location = $${params.length}`; }
        if (type) { params.push(type); sql += ` AND j.employmentType = $${params.length}`; }
        if (tags) { params.push(Array.isArray(tags) ? tags : [tags]); sql += ` AND j.tags @> $${params.length}`; }
        
        const res = await db.query(sql + ` ORDER BY j.createdAt DESC`, params);
        return res.rows;
    }

    async findById(id) {
        const res = await db.query('SELECT * FROM jobs WHERE id = $1', [id]);
        return res.rows[0];
    }

    async update(id, fields) {
        const allowed = ['title', 'tags', 'benefits', 'salaryMin', 'salaryMax', 'employmentType', 'description', 'location'];
        const keys = Object.keys(fields).filter(k => allowed.includes(k));
        if (keys.length === 0) return null;

        const setClause = keys.map((k, i) => `"${k}" = $${i + 2}`).join(', ');
        const values = keys.map(k => fields[k]);
        const sql = `UPDATE jobs SET ${setClause}, "updatedAt" = NOW() WHERE id = $1 RETURNING *`;
        
        const res = await db.query(sql, [id, ...values]);
        return res.rows[0];
    }

    async create(d) {
        const sql = `INSERT INTO jobs (companyId, title, tags, benefits, salaryMin, salaryMax, employmentType, description, location) 
                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`;
        const res = await db.query(sql, [d.companyId, d.title, d.tags, d.benefits, d.salaryMin, d.salaryMax, d.type, d.description, d.location]);
        return res.rows[0];
    }

    async delete(id) { await db.query('UPDATE jobs SET isActive = false WHERE id = $1', [id]); }
}

export default new JobRepository();