import express from 'express';
import swaggerUi from 'swagger-ui-express';
import swaggerJsdoc from 'swagger-jsdoc';
import * as jobCtrl from './modules/job/job.controller.js';

const app = express();
app.use(express.json());

// --- Cấu hình Swagger Options ---
const swaggerOptions = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'DEVision - Job Applicant API',
            version: '1.0.0',
            description: 'API Documentation for Job Applicant Subsystem',
        },
        servers: [{ url: 'http://localhost:3000' }],
    },
    apis: ['./src/app.js'], // Chỉ định nơi viết chú thích API
};

const specs = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));

/**
 * @openapi
 * /api/jobs:
 * get:
 * summary: Search and filter jobs
 * parameters:
 * - in: query
 * name: search
 * schema: { type: string }
 * - in: query
 * name: location
 * schema: { type: string }
 * responses:
 * 200:
 * description: Success
 * post:
 * summary: Create a new job
 * requestBody:
 * required: true
 * content:
 * application/json:
 * schema:
 * type: object
 * properties:
 * companyId: { type: integer }
 * title: { type: string }
 * tags: { type: array, items: { type: string } }
 * responses:
 * 201:
 * description: Created
 */
app.get('/api/jobs', jobCtrl.getAll);
app.post('/api/jobs', jobCtrl.create);

/**
 * @openapi
 * /api/jobs/{id}:
 * patch:
 * summary: Update job partially
 * parameters:
 * - in: path
 * name: id
 * required: true
 * schema: { type: integer }
 * responses:
 * 200:
 * description: Updated
 * delete:
 * summary: Deactivate a job
 * parameters:
 * - in: path
 * name: id
 * required: true
 * schema: { type: integer }
 * responses:
 * 204:
 * description: Deleted
 */
app.patch('/api/jobs/:id', jobCtrl.update);
app.delete('/api/jobs/:id', jobCtrl.remove);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    console.log(`Swagger docs available at http://localhost:${PORT}/api-docs`);
});